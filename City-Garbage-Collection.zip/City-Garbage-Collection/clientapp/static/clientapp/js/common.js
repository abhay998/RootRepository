$(document).ready(function(){
  $('#sidenav').html($('#nav').html())
  $(".button-collapse").sideNav();
});
