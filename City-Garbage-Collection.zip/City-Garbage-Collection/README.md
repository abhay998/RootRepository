# City-Garbage-Collection
Django application developed for managing garbage collection requests
